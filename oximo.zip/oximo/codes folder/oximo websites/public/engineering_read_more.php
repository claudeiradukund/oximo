           
           <?php
              include('database/dbase_connect.php');
              include('D:\xampp\htdocs\oximo websites\public\common_function\function.php');
              session_start();
            ?>
           <?php include('header.php'); ?>
           <!---show view more on engineering parts ---->
               <div class="containerr" style="background-color:rgb(240, 240, 240);">
           <div class="header">
             <h2 style="text-align:center">Engineering Description</h2>
           </div>
            <div class="form">
             <div class="forming" style="width:80%; margin-left:8%; margin-right:8%;">
                 <p style="text-align: justify; line-height: 1.5;">
                    Welcome to our comprehensive architectural and design firm, where innovation, engineering expertise, project management, interior design, and master planning converge to shape the world around us.
                    </p><p style="text-align: justify; line-height: 1.5;"> With a strong commitment to excellence, we are your trusted partner in bringing architectural visions to life. Our multidisciplinary team of architects, engineers, and designers work collaboratively to deliver integrated solutions that not only enhance the visual appeal but also prioritize functionality and sustainability.
                    </p><p style="text-align: justify; line-height: 1.5;"> From the inception of a project to its completion, our holistic approach ensures a seamless journey. We pride ourselves on turning ideas into realities, from residential spaces to large-scale urban developments.
                    </p><p style="text-align: justify; line-height: 1.5;"> Let us be your partner in creating environments that are not only aesthetically captivating but also purposeful and future-ready. Welcome to a world where architecture and design are transformed into enduring legacies.
                  </p>
              </div>
             <?php
             /// showing engineering read more
               displayengineeringreadmoreProjects();
             ?>
           </div>
        </div>
        <!---- end of project image and description ---->      
        <!-- include footer -->
        <?php include('D:\xampp\htdocs\oximo websites\public\footer\footer.php') ?>  
    </body>
</html>

                                                                                             

