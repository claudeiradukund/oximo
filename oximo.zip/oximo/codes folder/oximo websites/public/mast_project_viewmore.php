<?php
include('D:\xampp\htdocs\oximo websites\Admin_parts\config\dbcon.php');
include('D:\xampp\htdocs\oximo websites\public\common_function\function.php');
session_start();
?>
<?php include('header.php'); ?>
    <!---show view more on master planning projects ---->
       <div class="content">
          <!-- fetching projects using function -->
          <?php
            masterplanningProjects();
          ?>
              <div class="inputbox">
                <a href="contact.php"><input type="Submit" name="" value="Ask More On This Project" style="background-color:#00ccff;"></a>
              </div>
           </div>
        </div>
        <!-- include footer -->
        <?php include('D:\xampp\htdocs\oximo websites\public\footer\footer.php') ?>
    </body>
</html>