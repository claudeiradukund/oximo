-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 28, 2023 at 05:50 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `oximo`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_table`
--

CREATE TABLE IF NOT EXISTS `admin_table` (
`id` int(11) NOT NULL,
  `full_names` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `architecture_project`
--

CREATE TABLE IF NOT EXISTS `architecture_project` (
`id` int(11) NOT NULL,
  `project_description` mediumtext NOT NULL,
  `project_keywords` varchar(500) NOT NULL,
  `project_name` varchar(150) NOT NULL,
  `location` varchar(150) NOT NULL,
  `landscale` varchar(150) NOT NULL,
  `year` varchar(4) NOT NULL,
  `image1` varchar(255) NOT NULL,
  `image2` varchar(255) NOT NULL,
  `image3` varchar(255) NOT NULL,
  `image4` varchar(255) NOT NULL,
  `image5` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `architecture_project`
--

INSERT INTO `architecture_project` (`id`, `project_description`, `project_keywords`, `project_name`, `location`, `landscale`, `year`, `image1`, `image2`, `image3`, `image4`, `image5`, `date`) VALUES
(2, 'appartiment', 'oximo', 'claude appartiment', 'kigali', '20mx35m', '2021', 'house2.6.png', 'house2.5.png', '', 'house2.7.png', 'house2.png', '2023-12-08 14:07:51'),
(3, 'oximo houses designed in 2022', 'oximo', 'oximo', 'Norvege', '30mx40m', '2022', 'house1.3.png', 'house1.2.png', '', 'house1.4.png', 'house1.5.png', '2023-12-28 09:19:25');

-- --------------------------------------------------------

--
-- Table structure for table `customer_testimonials`
--

CREATE TABLE IF NOT EXISTS `customer_testimonials` (
`id` int(11) NOT NULL,
  `customer_messages` varchar(500) NOT NULL,
  `customer_names` varchar(100) NOT NULL,
  `customer_title` varchar(100) NOT NULL,
  `customer_image` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `customer_testimonials`
--

INSERT INTO `customer_testimonials` (`id`, `customer_messages`, `customer_names`, `customer_title`, `customer_image`, `date`) VALUES
(4, 'Working with Oximo Construction made our dream home a reality. Their architectural and engineering expertise transformed our ideas into a beautifully designed space.\r\nOximo provided exceptional construction services. Their attention to detail and commitment to quality resulted in a project that exceeded our expectations.\r\nHighly recommend Oximo for any architecture, engineering, and construction needs. Their professionalism and innovative solutions added value to our project.', 'KWIBUKA Bernard', 'Business men', 'simon8.jpg', '2023-12-08 18:18:21');

-- --------------------------------------------------------

--
-- Table structure for table `engineering_project`
--

CREATE TABLE IF NOT EXISTS `engineering_project` (
`id` int(11) NOT NULL,
  `project_name` varchar(50) NOT NULL,
  `project_description` varchar(50000) NOT NULL,
  `project_keywords` varchar(100) NOT NULL,
  `location` varchar(50) NOT NULL,
  `landscale` varchar(50) NOT NULL,
  `year` varchar(6) NOT NULL,
  `image1` varchar(255) NOT NULL,
  `image2` varchar(255) NOT NULL,
  `image3` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `engineering_project`
--

INSERT INTO `engineering_project` (`id`, `project_name`, `project_description`, `project_keywords`, `location`, `landscale`, `year`, `image1`, `image2`, `image3`, `date`) VALUES
(5, 'kiki- kigali', 'zxnznzn', 'kiki', 'kigali-gisozi', '20mx30m', '2020', 'house4.1.jfif', 'house3.jfif', '', '2023-12-08 15:31:10');

-- --------------------------------------------------------

--
-- Table structure for table `inserted_projects`
--

CREATE TABLE IF NOT EXISTS `inserted_projects` (
`id` int(11) NOT NULL,
  `project_title` varchar(255) NOT NULL,
  `project_description` varchar(400) NOT NULL,
  `project_keywords` varchar(355) NOT NULL,
  `project_location` varchar(150) NOT NULL,
  `image1` text NOT NULL,
  `image2` text NOT NULL,
  `image3` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `interior_design`
--

CREATE TABLE IF NOT EXISTS `interior_design` (
`id` int(11) NOT NULL,
  `project_name` varchar(100) NOT NULL,
  `project_description` mediumtext NOT NULL,
  `project_keywords` varchar(100) NOT NULL,
  `location` varchar(50) NOT NULL,
  `landscale` varchar(50) NOT NULL,
  `year` varchar(6) NOT NULL,
  `image1` varchar(255) NOT NULL,
  `image2` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `interior_design`
--

INSERT INTO `interior_design` (`id`, `project_name`, `project_description`, `project_keywords`, `location`, `landscale`, `year`, `image1`, `image2`, `date`) VALUES
(2, 'gad house', 'ajaakak', '', 'znsjjssj', 'ajaajja', '2019', 'house3.1.jfif', 'house3.jfif', '2023-12-08 15:33:20'),
(4, 'kiza house', 'oxxi , interior, houses', 'interior design housee', 'Norvegee kigali', '30mx35m', '2019', 'house4.4.jfif', 'house4.5.jfif', '2023-12-08 16:07:46');

-- --------------------------------------------------------

--
-- Table structure for table `master_planning`
--

CREATE TABLE IF NOT EXISTS `master_planning` (
`id` int(11) NOT NULL,
  `project_name` varchar(100) NOT NULL,
  `project_description` mediumtext NOT NULL,
  `project_keywords` varchar(100) NOT NULL,
  `location` varchar(50) NOT NULL,
  `landscale` varchar(50) NOT NULL,
  `year` varchar(6) NOT NULL,
  `image1` varchar(255) NOT NULL,
  `image2` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `project_management`
--

CREATE TABLE IF NOT EXISTS `project_management` (
`id` int(11) NOT NULL,
  `project_description` mediumtext NOT NULL,
  `project_keywords` varchar(100) NOT NULL,
  `project_name` varchar(100) NOT NULL,
  `location` varchar(50) NOT NULL,
  `project_landscale` varchar(24) NOT NULL,
  `year` varchar(6) NOT NULL,
  `image1` varchar(255) NOT NULL,
  `image2` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `project_management`
--

INSERT INTO `project_management` (`id`, `project_description`, `project_keywords`, `project_name`, `location`, `project_landscale`, `year`, `image1`, `image2`, `date`) VALUES
(3, 'yyussa plaza hipuu', 'campany house', 'yyussa', 'Nyabugogo', '30mx35m', '2018', 'house1.1.png', 'house1.2.png', '2023-12-04 23:20:04');

-- --------------------------------------------------------

--
-- Table structure for table `team_member`
--

CREATE TABLE IF NOT EXISTS `team_member` (
`id` int(11) NOT NULL,
  `names` varchar(100) NOT NULL,
  `degree` varchar(60) NOT NULL,
  `description` varchar(50000) NOT NULL,
  `image` varchar(150) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `team_member`
--

INSERT INTO `team_member` (`id`, `names`, `degree`, `description`, `image`, `date`) VALUES
(8, 'Mwizerwa', 'Engineering ', 'Working with Oximo Construction made our dream home a reality. Their architectural and engineering expertise transformed our ideas into a beautifully designed space.\r\n               Oximo provided exceptional construction services. Their attention to detail and commitment to quality resulted in a project that exceeded our expectations.\r\n               Highly recommend Oximo for any architecture, engineering, and construction needs. Their professionalism and innovative solutions added value to our project.', 'house4.jfif', '2023-12-08 21:24:10'),
(20, 'xx', 'xx', 'xnxnxnn', '4444.png', '2023-12-28 10:53:31');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) NOT NULL,
  `Firstname` text NOT NULL,
  `Lastname` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `role_as` tinyint(4) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `Datecreated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `Firstname`, `Lastname`, `email`, `Password`, `role_as`, `status`, `Datecreated`) VALUES
(8, 'IRADUKUNDA', 'IRADUKUNDA', 'iradujclaude@gmail.com', '$2y$10$fFswVyNZ67YeAZQR36CaX.3wW73lOhV9MT94EeyZnNd', 0, 0, '2023-12-15 16:32:25');

-- --------------------------------------------------------

--
-- Table structure for table `user_message`
--

CREATE TABLE IF NOT EXISTS `user_message` (
`id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `messages` varchar(900) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `user_message`
--

INSERT INTO `user_message` (`id`, `full_name`, `phone`, `email`, `messages`, `date`) VALUES
(1, 'IRADUKUNDA claude', '+250780072147', 'iradujclaude@gmail.com', 'dshshhshshshshh', '2023-12-08 20:22:53'),
(2, 'IRADUKUNDA claude', '+250780072147', 'iradujclaude@gmail.com', 'ssjsjfhfjfjfjfjjfjhchchchchch', '2023-12-08 20:23:07'),
(3, 'IRADUKUNDA claude', '+250780072147', 'iradujclaude@gmail.com', 'ssjsjfhfjfjfjfjjfjhchchchchch', '2023-12-08 20:23:36'),
(4, 'IRADUKUNDA claude', '+250780072147', 'iradujclaude@gmail.com', 'ssjsjfhfjfjfjfjjfjhchchchchch', '2023-12-08 20:24:08'),
(5, 'IRADUKUNDA claude', '+250780072147', 'iradujclaude@gmail.com', 'agaaahha', '2023-12-08 20:32:17'),
(6, 'IRADUKUNDA claude', '+250780072147', 'iradujclaude@gmail.com', 'claude', '2023-12-08 20:34:35'),
(7, 'IRADUKUNDA claude', '+250780072147', 'iradujclaude@gmail.com', 'ccckccl', '2023-12-08 20:35:08'),
(8, 'IRADUKUNDA claude', '+250780072147', 'iradujclaude@gmail.com', 'dgrsghrfgtghdcvgdfgc', '2023-12-09 07:11:03'),
(9, 'IRADUKUNDA claude', '+250780072147', 'iradujclaude@gmail.com', 'xxxxjxjjx', '2023-12-09 07:12:03'),
(10, 'IRADUKUNDA claude', '+250780072147', 'iradujclaude@gmail.com', 'xxgxhzxjkzkaskakllaalajaj', '2023-12-11 20:18:23'),
(11, 'IRADUKUNDA claude', '+250780072147', 'iradujclaude@gmail.com', 'mnkjolkokl', '2023-12-19 12:49:23'),
(12, 'IRADUKUNDA claude', '+250780072147', 'iradujclaude@gmail.com', 'ghjgv this is my messages.\r\n', '2023-12-22 08:05:00'),
(13, 'IRADUKUNDA claude', '+250780072147', 'iradujclaude@gmail.com', 'hhhhhh', '2023-12-22 08:05:40'),
(14, 'IRADUKUNDA claude', '+250780072147', 'iradujclaude@gmail.com', 'jjhhjjj', '2023-12-22 08:17:12'),
(15, 'IRADUKUNDA claude', '+250780072147', 'iradujclaude@gmail.com', 'hhhhhhh', '2023-12-22 08:17:54'),
(16, 'lamnbbwbwb', '08998', 'lmurindangabo@gmail.com', 'hello', '2023-12-28 09:28:30');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE IF NOT EXISTS `user_table` (
`id` int(11) NOT NULL,
  `user_username` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `user_ip` varchar(500) NOT NULL,
  `user_address` varchar(50) NOT NULL,
  `user_contact` varchar(10) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`id`, `user_username`, `user_email`, `user_password`, `user_ip`, `user_address`, `user_contact`, `date`) VALUES
(4, 'kiki', 'iradugclaude@gmail.com', '$2y$10$NnC2xTpMnReXpBKuPciGgetED2LNc3Sak8tFEnDw.DD', '::1', 'kigali', '0780072146', '2023-12-23 13:01:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_table`
--
ALTER TABLE `admin_table`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `architecture_project`
--
ALTER TABLE `architecture_project`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_testimonials`
--
ALTER TABLE `customer_testimonials`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `engineering_project`
--
ALTER TABLE `engineering_project`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inserted_projects`
--
ALTER TABLE `inserted_projects`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `interior_design`
--
ALTER TABLE `interior_design`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_planning`
--
ALTER TABLE `master_planning`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_management`
--
ALTER TABLE `project_management`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team_member`
--
ALTER TABLE `team_member`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_message`
--
ALTER TABLE `user_message`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_table`
--
ALTER TABLE `admin_table`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `architecture_project`
--
ALTER TABLE `architecture_project`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `customer_testimonials`
--
ALTER TABLE `customer_testimonials`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `engineering_project`
--
ALTER TABLE `engineering_project`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `inserted_projects`
--
ALTER TABLE `inserted_projects`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `interior_design`
--
ALTER TABLE `interior_design`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `master_planning`
--
ALTER TABLE `master_planning`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `project_management`
--
ALTER TABLE `project_management`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `team_member`
--
ALTER TABLE `team_member`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `user_message`
--
ALTER TABLE `user_message`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
