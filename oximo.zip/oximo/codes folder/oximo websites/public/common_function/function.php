<!---- data base connection ---->
<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "oximo";

// Establish connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	header("location:errors/dberror.php");
}
?>
<!---- fetching products from data base ------>
<?php
// Function to fetch and display data from architecture_project table
function displayArchitectureProjects(){
    global $conn;
        if (isset($_GET['project_data'])) {
        // echo 'HEY '. $_GET['project_data'];
        $myData = $_GET['project_data'];
        $select_query="SELECT * FROM `architecture_project` where id = $myData";
        $result_query=mysqli_query($conn,$select_query);
        while($row=mysqli_fetch_assoc($result_query)){
        $project_id=$row['id'];
        $project_title = $row['project_name'];
        $project_description = $row['project_description']; // Assuming this field was missing in the form and added here
        $project_keywords = $row['project_keywords'];
        $project_location = $row['location'];
        $project_landscale = $row['landscale'];
        $project_year = $row['year'];
        // File handling for images (omitted for brevity)
        // Handling file uploads
        $image1 = $row['image1'];
        $image2 = $row['image2'];
        $image3 = $row['image3'];
        $image4 = $row['image4'];
        $image5 = $row['image5'];
        // Check for duplicate entry
        
        // Display project details, you can format this as needed
        echo" <h2>Project Descriptions</h2>
        <div class='format'>
        <div class='projectdetails'>
        <p>$project_description</p>
        </div>
        <div class='project-description'>
        <h4>PROJECT NAME: $project_title</h4>
        <p>LOCATION: $project_location</p>
        <p>LAND SCALE: $project_landscale</p>
        <p>YEAR: $project_year</p>
        </div>
        <div class='images_more'>
        <img src='..\Admin_parts\all_images/$image1' alt='$project_title' style='width:100%;'>
        <img src='..\Admin_parts\all_images/$image2' alt='$project_title' style='width:100%;'>
        <img src='..\Admin_parts\all_images/$image3' alt='$project_title' style='width:100%;'>
        <img src='..\Admin_parts\all_images/$image4' alt='$project_title' style='width:100%;'>
        <img src='..\Admin_parts\all_images/$image5' alt='$project_title' style='width:100%;'>
        </div>";
        }
    }

}
/// Architecture read more and see some projects
function displayArchitecturereadmoreProjects(){
    global $conn;
        if (!isset($_GET['architecture_readmore'])) {
        $select_query="SELECT `id`, `project_name`, `image1` FROM `architecture_project` ORDER BY id";
        $result_query=mysqli_query($conn,$select_query);
        while($row=mysqli_fetch_assoc($result_query)){
        $project_id=$row['id'];
        $project_title = $row['project_name'];
        $image1 = $row['image1'];
        // Display project details, you can format this as needed
        if($project_id>=0){
                 echo "<h4 style='text-align:center; color:black;'>$project_title</h4>";
                 echo"  <div class='images'>
                 <img src='..\Admin_parts\all_images/$image1' class='card-img-top' alt='$project_title' style='width:100%;'>
                 <a href='arch_project_viewmore.php?project_data=$project_id'><input type='button' name='view_more' value='view more' style='background-color:#00ccff'></a>
              </div>";
        }
        }
    }

}
  // Function to fetch and display data from engineering_project table
function engineeringProjects(){
    global $conn;     

    if (isset($_GET['project_id_eng'])) {
        $my_eng_data=$_GET['project_id_eng'];
        $select_query = "SELECT * FROM `engineering_project` WHERE id=$my_eng_data";
        
        // Execute the query and check for errors
        $result_query = mysqli_query($conn, $select_query);

        if (!$result_query) {
            // Print the SQL error for debugging
            echo "Error: " . mysqli_error($conn);
        } else {
            // Fetch rows if the query was successful
            while ($row = mysqli_fetch_assoc($result_query)) {
                $project_id = $row['id'];
                $project_title = $row['project_name'];
                $project_description = $row['project_description'];
                $project_keywords = $row['project_keywords'];
                $project_location = $row['location'];
                $project_landscape = $row['landscale'];
                $project_year = $row['year'];
                $image1 = $row['image1'];
                $image2 = $row['image2'];
                $image3 = $row['image3'];
                
                // Display project details
                echo "<h2>Project Descriptions</h2>
                    <div class='format'>
                        <div class='projectdetails'>
                            <p>$project_description</p>
                        </div>
                        <div class='project-description'>
                            <h4>PROJECT NAME: $project_title</h4>
                            <p>LOCATION: $project_location</p>
                            <p>LAND SCALE: $project_landscape</p>
                            <p>YEAR: $project_year</p>
                        </div>
                        <div class='images_more'>
                            <img src='..\Admin_parts\all_images/$image1' alt='$project_title' style='width:100%;'>
                            <img src='..\Admin_parts\all_images/$image2' alt='$project_title' style='width:100%;'>
                            <img src='..\Admin_parts\all_images/$image3' alt='$project_title' style='width:100%;'>
                        </div>
                    </div>";
            }
        }
    }
}

/// engineeringproject read more and see some projects
function displayengineeringreadmoreProjects(){
    global $conn;
       if (!isset($_GET['engineeringview_more'])) {
        $select_query="SELECT `id`, `project_name`, `image1` FROM `engineering_project` ORDER BY id";
        $result_query=mysqli_query($conn,$select_query);
        while($row=mysqli_fetch_assoc($result_query)){
        $project_id=$row['id'];
        $project_title = $row['project_name'];
        $image1 = $row['image1'];
        // Display project details, you can format this as needed
        if($project_id>=0){
                 echo "<h4 style='text-align:center; color:black;'>$project_title</h4>";
                 echo"  <div class='images'>
                 <img src='..\Admin_parts\all_images/$image1' class='card-img-top' alt='$project_title' style='width:100%;'>
                 <a href='eng_project_viewmore.php?project_id_eng=$project_id'><input type='button' name='view_more' value='view more' style='background-color:#00ccff'></a>
              </div>";
        }
        }
    }
}
 // Function to fetch and display data from interior design_project table
 function interiordesignProjects(){
    global $conn;
         
        if (isset($_GET['interior_data'])) {
        $my_interior=$_GET['interior_data'];
        $select_query="SELECT * FROM `interior_design` WHERE id=$my_interior";
        $result_query=mysqli_query($conn,$select_query);
        while($row=mysqli_fetch_assoc($result_query)){
        $project_id=$row['id'];
        $project_title = $row['project_name'];
        $project_description = $row['project_description']; // Assuming this field was missing in the form and added here
        $project_keywords = $row['project_keywords'];
        $project_location = $row['location'];
        $project_landscale = $row['landscale'];
        $project_year = $row['year'];
        // File handling for images (omitted for brevity)
        // Handling file uploads
        $image1 = $row['image1'];
        $image2 = $row['image2'];
        // Check for duplicate entry
        
        // Display project details, you can format this as needed
        echo" <h2>Project Descriptions</h2>
        <div class='format'>
        <div class='projectdetails'>
        <p>$project_description</p>
        </div>
        <div class='project-description'>
        <h4>PROJECT NAME: $project_title</h4>
        <p>LOCATION: $project_location</p>
        <p>LAND SCALE: $project_landscale</p>
        <p>YEAR: $project_year</p>
        </div>
        <div class='images_more'>
        <img src='..\Admin_parts\all_images/$image1' alt='$project_title' style='width:100%;'>
        <img src='..\Admin_parts\all_images/$image2' alt='$project_title' style='width:100%;'>
        </div>";
        }
    }

}
/// interiordesignProjects read more and see some projects
function interiordesignreadmoreProjects(){
    global $conn;
        if (!isset($_GET['interiordeign'])) {
        $select_query="SELECT `id`, `project_name`, `image1` FROM `interior_design` ORDER BY id";
        $result_query=mysqli_query($conn,$select_query);
        while($row=mysqli_fetch_assoc($result_query)){
        $project_id=$row['id'];
        $project_title = $row['project_name'];
        $image1 = $row['image1'];
        // Display project details, you can format this as needed
        if($project_id>=0){
                 echo "<h4 style='text-align:center; color:black;'>$project_title</h4>";
                 echo"  <div class='images'>
                 <img src='..\Admin_parts\all_images/$image1' class='card-img-top' alt='$project_title' style='width:100%;'>
                 <a href='inter_project_viewmore.php?interior_data=$project_id'><input type='button' name='view_more' value='view more' style='background-color:#00ccff'></a>
              </div>";
        }
        }
    }

}
// Function to fetch and display data from master planning_project table
 function masterplanningProjects(){
    global $conn;
         
        if (isset($_GET['master_data'])) {
        $master_data_show=$_GET['master_data'];
        $select_query="SELECT * FROM `master_planning` WHERE id=$master_data_show";
        $result_query=mysqli_query($conn,$select_query);
        while($row=mysqli_fetch_assoc($result_query)){
        $project_id=$row['id'];
        $project_title = $row['project_name'];
        $project_description = $row['project_description']; // Assuming this field was missing in the form and added here
        $project_keywords = $row['project_keywords'];
        $project_location = $row['location'];
        $project_landscale = $row['landscale'];
        $project_year = $row['year'];
        // File handling for images (omitted for brevity)
        // Handling file uploads
        $image1 = $row['image1'];
        $image2 = $row['image2'];
        // Check for duplicate entry
        
        // Display project details, you can format this as needed
        echo" <h2>Project Descriptions</h2>
        <div class='format'>
        <div class='projectdetails'>
        <p>$project_description</p>
        </div>
        <div class='project-description'>
        <h4>PROJECT NAME: $project_title</h4>
        <p>LOCATION: $project_location</p>
        <p>LAND SCALE: $project_landscale</p>
        <p>YEAR: $project_year</p>
        </div>
        <div class='images_more'>
        <img src='..\Admin_parts\all_images/$image1' alt='$project_title' style='width:100%;'>
        <img src='..\Admin_parts\all_images/$image2' alt='$project_title' style='width:100%;'>
        </div>";
        }
    }

}
/// interiordesignProjects read more and see some projects
function masterplanningreadmoreProjects(){
    global $conn;
       if (!isset($_GET['masterplanningmore_project'])) {
        $select_query="SELECT `id`, `project_name`, `image1` FROM `master_planning` ORDER BY id";
        $result_query=mysqli_query($conn,$select_query);
        while($row=mysqli_fetch_assoc($result_query)){
        $project_id=$row['id'];
        $project_title = $row['project_name'];
        $image1 = $row['image1'];
        // Display project details, you can format this as needed
        if($project_id>=0){
                 echo "<h4 style='text-align:center; color:black;'>$project_title</h4>";
                 echo"  <div class='images'>
                 <img src='..\Admin_parts\all_images/$image1' class='card-img-top' alt='$project_title' style='width:100%;'>
                 <a href='mast_project_viewmore.php?master_data=$project_id'><input type='button' name='view_more' value='view more' style='background-color:#00ccff'></a>
              </div>";
        }
        }
    }
}
// Function to fetch and display data from project management_project table
 function projectmanagement(){
    global $conn;
         
        if (isset($_GET['project_read'])) {
        $my_data_in_project=$_GET['project_read'];
        $select_query="SELECT * FROM `project_management` WHERE id=$my_data_in_project";
        $result_query=mysqli_query($conn,$select_query);
        while($row=mysqli_fetch_assoc($result_query)){
        $project_id=$row['id'];
        $project_title = $row['project_name'];
        $project_description = $row['project_description']; // Assuming this field was missing in the form and added here
        $project_keywords = $row['project_keywords'];
        $project_location = $row['location'];
        $project_year = $row['year'];
        // File handling for images (omitted for brevity)
        // Handling file uploads
        $image1 = $row['image1'];
        $image2 = $row['image2'];
        // Check for duplicate entry
        
        // Display project details, you can format this as needed
        echo" <h2>Project Descriptions</h2>
        <div class='format'>
        <div class='projectdetails'>
        <p>$project_description</p>
        </div>
        <div class='project-description'>
        <h4>PROJECT NAME: $project_title</h4>
        <p>LOCATION: $project_location</p>
        <p>YEAR: $project_year</p>
        </div>
        <div class='images_more'>
        <img src='..\Admin_parts\all_images/$image1' alt='$project_title' style='width:100%;'>
        <img src='..\Admin_parts\all_images/$image2' alt='$project_title' style='width:100%;'>
        </div>";
        }
    }

}
/// project management read more and see some projects
function projectmanagementreadmoreProjects(){
    global $conn;
        if (!isset($_GET['project_managementmore'])) {
        $select_query="SELECT `id`, `project_name`, `image1` FROM `project_management` ORDER BY id";
        $result_query=mysqli_query($conn,$select_query);
        while($row=mysqli_fetch_assoc($result_query)){
        $project_id=$row['id'];
        $project_title = $row['project_name'];
        $image1 = $row['image1'];
        // Display project details, you can format this as needed
        if($project_id>=0){
                 echo "<h4 style='text-align:center; color:black;'>$project_title</h4>";
                 echo"  <div class='images'>
                 <img src='..\Admin_parts\all_images/$image1' class='card-img-top' alt='$project_title' style='width:100%;'>
                 <a href='projmana_project_viewmore.php?project_read=$project_id'><input type='button' name='view_more' value='view more' style='background-color:#00c2ff'></a>
              </div>";
        }
        }
    }

}
// Functions for customer testimonials
function displaycustomer_testimonials(){
    global $conn;
        if (!isset($_GET['testimonials'])) {
        $select_query="SELECT `id`, `customer_messages`, `customer_names`, `customer_title`, `customer_image`, `date` FROM `customer_testimonials` ORDER BY id";
        $result_query=mysqli_query($conn,$select_query);
        while($row=mysqli_fetch_assoc($result_query)){
        $customer_messages=$row['customer_messages'];
        $customer_names = $row['customer_names'];
        $customer_title = $row['customer_title']; // Assuming this field was missing in the form and added here
        // File handling for images (omitted for brevity)
        // Handling file uploads
        $customer_image = $row['customer_image'];
        // Check for duplicate entry
        
        // Display project details, you can format this as needed
        echo" <div class='card'>
               <img src='../Admin_parts/testimonial_image/$customer_image' alt='$customer_names' style='width:100%;'>
               <p>$customer_messages</p>
               <h2>$customer_names</h2>
               <h4>$customer_title</h4>
               <i class='fa fa-quote-left'></i>
               </div>";       
        }
    }

}
// Functions for customer testimonials
function displayleadership(){
    global $conn;
        if (!isset($_GET['ourleadership'])) {
        $select_query="SELECT `id`, `names`, `degree`, `description`, `image`, `date` FROM `team_member` ORDER BY id";
        $result_query=mysqli_query($conn,$select_query);
        while($row=mysqli_fetch_assoc($result_query)){
        $names=$row['names'];
        $post_or_title = $row['degree'];
        $qualities_description = $row['description'];
        $leader_image = $row['image'];
        // Check for duplicate entry
        echo"<div class='profile'>
               <img src='../Admin_parts/team_member_images/$leader_image' class='profile-img'>
               <h3 class='user-name'>$names</h3>
               <h5>$post_or_title</h5>
               <p class='paragraph'>$qualities_description</p>
               </div>";
        }    
    }
 }

 /// view all projects using functions and showing on projects pagesyw
 function view_allproject(){
     global $conn;        
     if (!isset($_GET['viewmore'])) {
        // Query 1: Fetch data from architecture_project table
        $query1 = "SELECT `id`, `project_description`, `project_keywords`, `project_name`, `location`, `landscale`, `year`, `image1`, `image2`, `image3`, `image4`, `image5`, `date` FROM `architecture_project` ORDER BY id";
        $result1 = $conn->query($query1);

        // Query 2: Fetch data from interior_design table
        $query2 = "SELECT `id`, `project_name`, `project_description`, `project_keywords`, `location`, `landscale`, `year`, `image1`, `image2`, `date` FROM `interior_design` ORDER BY id";
        $result2 = $conn->query($query2);

        // Query 3: Fetch data from project_management table
        $query3 = "SELECT `id`, `project_description`, `project_keywords`, `project_name`, `location`, `year`, `image1`, `image2`, `date` FROM `project_management` ORDER BY id";
        $result3 = $conn->query($query3);
        // Query 4: Fetch data from master planning table
        $query4 = "SELECT `id`, `project_name`, `project_description`, `project_keywords`, `location`, `landscale`, `year`, `image1`, `image2`, `date` FROM `master_planning` ORDER BY id";
        $result4 = $conn->query($query4);
        // Query 5: Fetch data from engineering table
        $query5 = "SELECT * FROM `engineering_project` ORDER BY id";
        $result5 = $conn->query($query5);

        // Display data from Query 1 (architecture_project)
        if ($result1->num_rows > 0) {
            while ($row = $result1->fetch_assoc()) {
                $project_id=$row['id'];
                $project_title = $row['project_name'];
                $project_description = $row['project_description']; // Assuming this field was missing in the form and added here
                $project_keywords = $row['project_keywords'];
                $project_location = $row['location'];
                $project_landscale = $row['landscale'];
                $project_year = $row['year'];
                $image1 = $row['image1'];
                // Display fetched data from architecture_project
                // You can format the display as per your requirement
                echo" <div class='card'>
                    <img src='..\Admin_parts\all_images/$image1' class='card-img-top' alt='...' style='width:80%;'>
                    <div class='card-body'>
                         <div class='project-description'>
                           <h4>PROJECT NAME: $project_title</h4>
                           <p>LOCATION: $project_location</p>
                           <p>LAND SCALE: $project_landscale</p>
                         </div>
                         <div class='inputbox'>
                           <a href='arch_project_viewmore.php?project_data=$project_id'><input type='Submit' name='view_more' value='View more' style='color:#000000;background-color:#00CCFF;'></a>
                         </div>
                    </div>
                 </div>";
            }
        } else {
            echo "No results found for architecture_project";
        }
        // Display data from Query 2 (interiordesign_project)
        if ($result2->num_rows > 0) {
            while ($row = $result2->fetch_assoc()) {
                $project_id1=$row['id'];
                $project_title1 = $row['project_name'];
                $project_description1 = $row['project_description']; // Assuming this field was missing in the form and added here
                $project_keywords1 = $row['project_keywords'];
                $project_location1 = $row['location'];
                $project_landscale1 = $row['landscale'];
                $project_year1 = $row['year'];
                $image1 = $row['image1'];
                // Display fetched data from interior design
               
             echo" <div class='card'>
                    <img src='..\Admin_parts\all_images/$image1' class='card-img-top' alt='...' style='width:80%;'>
                    <div class='card-body'>
                         <div class='project-description'>
                           <h4>PROJECT NAME: $project_title1</h4>
                           <p>LOCATION: $project_location1</p>
                           <p>LAND SCALE: $project_landscale1</p>
                         </div>
                         <div class='inputbox'>
                           <a href='inter_project_viewmore.php?interior_data=$project_id1'><input type='Submit' name='view_more' value='View more' style='color:#000000;background-color:#00CCFF;'></a>
                         </div>
                    </div>
                 </div>";
            }
        } else {
            echo "No results found for interior_design_project";
        }
        
        // Display data from Query 3 (project_management)
        if ($result3->num_rows > 0) {
            while ($row = $result3->fetch_assoc()) {
                $project_id2=$row['id'];
                $project_title2 = $row['project_name'];
                $project_description2 = $row['project_description']; // Assuming this field was missing in the form and added here
                $project_keywords2 = $row['project_keywords'];
                $project_location2 = $row['location'];
                $project_year2 = $row['year'];
                $image1 = $row['image1'];
                // Display fetched data from project_management_project
               
               echo" <div class='card'>
                    <img src='..\Admin_parts\all_images/$image1' class='card-img-top' alt='...' style='width:80%;'>
                    <div class='card-body'>
                         <div class='project-description'>
                           <h4>PROJECT NAME: $project_title2</h4>
                           <p>LOCATION: $project_location2</p>
                           <p>Year: $project_year2</p>
                         </div>
                         <div class='inputbox'>
                           <a href='projmana_project_viewmore.php?project_read=$project_id2'><input type='Submit' name='view_more' value='View more' style='color:#000000; background-color:#00CCff;'></a>
                         </div>
                    </div>
                 </div>";
            }
        } else {
            echo "No results found for project_management";
        }
        
        // Display data from Query 4 (master planning_project)
        if ($result4->num_rows > 0) {
            while ($row = $result4->fetch_assoc()) {
                $project_id3=$row['id'];
                $project_title3 = $row['project_name'];
                $project_description3 = $row['project_description']; // Assuming this field was missing in the form and added here
                $project_keywords3 = $row['project_keywords'];
                $project_location3 = $row['location'];
                $project_landscale3 = $row['landscale'];
                $project_year3 = $row['year'];
                 $image1 = $row['image1'];
                // Display fetched data from master planning_project
              
             echo" <div class='card'>
                    <img src='..\Admin_parts\all_images/$image1' class='card-img-top' alt='...' style='width:80%;'>
                    <div class='card-body'>
                         <div class='project-description'>
                           <h4>PROJECT NAME: $project_title3</h4>
                           <p>LOCATION: $project_location3</p>
                           <p>Year: $project_year3</p>
                         </div>
                         <div class='inputbox'>
                           <a href='mast_project_viewmore.php?master_data=$project_id3'><input type='Submit' name='view_more' value='View more' style='color:#000000;background-color:#00CCFF;'></a>
                         </div>
                    </div>
                 </div>";
            }
        } else {
            echo "No results found for master planning_project";
        }
        
        // Display data from Query 5 (engineering_project)
        if($result5->num_rows >0) {
            while($row = $result5->fetch_assoc()) {
                $project_id4=$row['id'];
                $project_title4 = $row['project_name'];
                $project_description4 = $row['project_description']; // Assuming this field was missing in the form and added here
                $project_keywords4 = $row['project_keywords'];
                $project_location4 = $row['location'];
                $project_landscale4 = $row['landscale'];
                $project_year4 = $row['year'];
                $image1 = $row['image1'];
                // Display fetched data from engineering_project
                echo"<div class='card'>
                    <img src='..\Admin_parts\all_images/$image1' class='card-img-top' alt='...' style='width:80%;'>
                    <div class='card-body'>
                         <div class='project-description'>
                           <h4>PROJECT NAME: $project_title4</h4>
                           <p>LOCATION: $project_location4</p>
                           <p>Year: $project_year4</p>
                         </div>
                         <div class='inputbox'>
                           <a href='eng_project_viewmore.php?project_id_eng=$project_id4'><input type='Submit' name='view_more' value='View more' style='color:#000000;background-color:#00CCFF;'></a>
                         </div>
                    </div>
                 </div>";
            }
        } else {
            echo "No results found for engineering_project";
        }
     }
 }
 /// view all projects using functions and showing on projects pagesyw
 function searching_allproject(){
 global $conn;        
 if (!isset($_GET['search_data_product'])) {
         $searching_data=$_GET['search_data_product'];
        // Query 1: Fetch data from architecture_project table
        $query1 = "SELECT * FROM `architecture_project` WHERE project_keywords like'%$searching_data%'";
        $result1 = $conn->query($query1);

        // Query 2: Fetch data from interior_design table
        $query2 = "SELECT * FROM `interior_design` WHERE project_keywords like'%$searching_data%'";
        $result2 = $conn->query($query2);

        // Query 3: Fetch data from project_management table
        $query3 = "SELECT * FROM `project_management` WHERE project_keywords like'%$searching_data%'";
        $result3 = $conn->query($query3);
        // Query 4: Fetch data from master planning table
        $query4 = "SELECT * FROM `master_planning` WHERE project_keywords like'%$searching_data%'";
        $result4 = $conn->query($query4);
        // Query 5: Fetch data from engineering table
        $query5 = "SELECT * FROM `engineering_project` WHERE project_keywords like'%$searching_data%'";
        $result5 = $conn->query($query5);

        // Display data from Query 1 (architecture_project)
        if ($result1->num_rows > 0) {
            while ($row = $result1->fetch_assoc()) {
                $project_id=$row['id'];
                $project_title = $row['project_name'];
                $project_description = $row['project_description']; // Assuming this field was missing in the form and added here
                $project_keywords = $row['project_keywords'];
                $project_location = $row['location'];
                $project_landscale = $row['landscale'];
                $project_year = $row['year'];
                $image1 = $row['image1'];
                // Display fetched data from architecture_project
                // You can format the display as per your requirement
                echo" <div class='card'>
                    <img src='..\Admin_parts\all_images/$image1' class='card-img-top' alt='...' style='width:80%;'>
                    <div class='card-body'>
                         <div class='project-description'>
                           <h4>PROJECT NAME: $project_title</h4>
                           <p>LOCATION: $project_location</p>
                           <p>LAND SCALE: $project_landscale</p>
                         </div>
                         <div class='inputbox'>
                           <a href='arch_project_viewmore.php?project_data=$project_id'><input type='Submit' name='view_more' value='View more' style='color:#000000;background-color:#00CCFF;'></a>
                         </div>
                    </div>
                 </div>";
            }
        }
        // Display data from Query 2 (interiordesign_project)
        if ($result2->num_rows > 0) {
            while ($row = $result2->fetch_assoc()) {
                $project_id1=$row['id'];
                $project_title1 = $row['project_name'];
                $project_description1 = $row['project_description']; // Assuming this field was missing in the form and added here
                $project_keywords1 = $row['project_keywords'];
                $project_location1 = $row['location'];
                $project_landscale1 = $row['landscale'];
                $project_year1 = $row['year'];
                $image1 = $row['image1'];
                // Display fetched data from interior design
               
             echo" <div class='card'>
                    <img src='..\Admin_parts\all_images/$image1' class='card-img-top' alt='...' style='width:80%;'>
                    <div class='card-body'>
                         <div class='project-description'>
                           <h4>PROJECT NAME: $project_title1</h4>
                           <p>LOCATION: $project_location1</p>
                           <p>LAND SCALE: $project_landscale1</p>
                         </div>
                         <div class='inputbox'>
                           <a href='inter_project_viewmore.php?interior_data=$project_id1'><input type='Submit' name='view_more' value='View more' style='color:#000000;background-color:#00CCFF;'></a>
                         </div>
                    </div>
                 </div>";
            }
        } 
        
        // Display data from Query 3 (project_management)
        if ($result3->num_rows > 0) {
            while ($row = $result3->fetch_assoc()) {
                $project_id2=$row['id'];
                $project_title2 = $row['project_name'];
                $project_description2 = $row['project_description']; // Assuming this field was missing in the form and added here
                $project_keywords2 = $row['project_keywords'];
                $project_location2 = $row['location'];
                $project_year2 = $row['year'];
                $image1 = $row['image1'];
                // Display fetched data from project_management_project
               
               echo" <div class='card'>
                    <img src='..\Admin_parts\all_images/$image1' class='card-img-top' alt='...' style='width:80%;'>
                    <div class='card-body'>
                         <div class='project-description'>
                           <h4>PROJECT NAME: $project_title2</h4>
                           <p>LOCATION: $project_location2</p>
                           <p>Year: $project_year2</p>
                         </div>
                         <div class='inputbox'>
                           <a href='projmana_project_viewmore.php?project_read=$project_id2'><input type='Submit' name='view_more' value='View more' style='color:#000000; background-color:#00CCff;'></a>
                         </div>
                    </div>
                 </div>";
            }
        }         
        // Display data from Query 4 (master planning_project)
        if ($result4->num_rows > 0) {
            while ($row = $result4->fetch_assoc()) {
                $project_id3=$row['id'];
                $project_title3 = $row['project_name'];
                $project_description3 = $row['project_description']; // Assuming this field was missing in the form and added here
                $project_keywords3 = $row['project_keywords'];
                $project_location3 = $row['location'];
                $project_landscale3 = $row['landscale'];
                $project_year3 = $row['year'];
                 $image1 = $row['image1'];
                // Display fetched data from master planning_project
              
             echo" <div class='card'>
                    <img src='..\Admin_parts\all_images/$image1' class='card-img-top' alt='...' style='width:80%;'>
                    <div class='card-body'>
                         <div class='project-description'>
                           <h4>PROJECT NAME: $project_title3</h4>
                           <p>LOCATION: $project_location3</p>
                           <p>Year: $project_year3</p>
                         </div>
                         <div class='inputbox'>
                           <a href='mast_project_viewmore.php?master_data=$project_id3'><input type='Submit' name='view_more' value='View more' style='color:#000000;background-color:#00CCFF;'></a>
                         </div>
                    </div>
                 </div>";
             }
        }
        
        // Display data from Query 5 (engineering_project)
        if($result5->num_rows >0) {
            while($row = $result5->fetch_assoc()) {
                $project_id4=$row['id'];
                $project_title4 = $row['project_name'];
                $project_description4 = $row['project_description']; // Assuming this field was missing in the form and added here
                $project_keywords4 = $row['project_keywords'];
                $project_location4 = $row['location'];
                $project_landscale4 = $row['landscale'];
                $project_year4 = $row['year'];
                $image1 = $row['image1'];
                // Display fetched data from engineering_project
                echo"<div class='card'>
                    <img src='..\Admin_parts\all_images/$image1' class='card-img-top' alt='...' style='width:80%;'>
                    <div class='card-body'>
                         <div class='project-description'>
                           <h4>PROJECT NAME: $project_title4</h4>
                           <p>LOCATION: $project_location4</p>
                           <p>Year: $project_year4</p>
                         </div>
                         <div class='inputbox'>
                           <a href='eng_project_viewmore.php?project_id_eng=$project_id4'><input type='Submit' name='view_more' value='View more' style='color:#000000;background-color:#00CCFF;'></a>
                         </div>
                    </div>
                 </div>";
            }
        }
     }else {          
            echo "
         <div style='height:400px;'>
         <h2 class='text-center text-danger' style='color:#e91e63; text-align:center; margin-top:100px;'>no results match. no projects found!</h2>
         </div>";
        }
 }
?>